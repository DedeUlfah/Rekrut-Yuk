from flask import Flask, render_template, request, redirect
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import LabelEncoder
import pandas as pd

app = Flask(__name__)

# Variabel global untuk menyimpan model dan pipeline
model_knn = KNeighborsClassifier(n_neighbors=7)
pipeline = None
uploaded_data = None

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/proses_upload', methods=['POST'])
def proses_upload():
    global uploaded_data, pipeline, model_knn

    if 'file' not in request.files:
        return redirect(request.url)

    file = request.files['file']

    if file.filename == '':
        return redirect(request.url)

    if file:
        # Simpan file di server atau lakukan pemrosesan yang diperlukan
        file_path = 'Employee_data.xlsx'
        file.save(file_path)

        # Baca data dari file excel
        uploaded_data = pd.read_excel(file_path)

        # Ubah nilai string pada kolom 'pendidikan'
        pendidikan_mapping = {"Bachelor's": 1, "Master's & above": 2, 'Below Secondary': 0}
        uploaded_data['pendidikan'] = uploaded_data['pendidikan'].map(pendidikan_mapping)

        le = LabelEncoder()
        uploaded_data['jenis_kelamin'] = le.fit_transform(uploaded_data['jenis_kelamin'])

        # Training ulang model KNN dengan data yang baru diunggah
        X = uploaded_data.iloc[:, :-1].values
        y = uploaded_data.iloc[:, -1].values

        # Membuat pipeline untuk menangani nilai yang hilang
        pipeline = Pipeline([
            ('imputer', SimpleImputer(strategy='mean')),
            ('scaler', StandardScaler())
        ])

        # Melakukan transformasi pada data
        X_processed = pipeline.fit_transform(X)

        # Split data untuk melatih dan menguji
        X_train, X_test, y_train, y_test = train_test_split(X_processed, y, test_size=0.2, random_state=42)

        # Latih model KNN
        model_knn.fit(X_train, y_train)

        # Lakukan prediksi pada data yang diunggah
        predictions = model_knn.predict(X_processed)

        # Tambahkan kolom 'penerimaan' dengan hasil prediksi ke dalam DataFrame
        uploaded_data['penerimaan'] = predictions

        return render_template('hasil.html', hasil_df=uploaded_data[['id_karyawan', 'penerimaan']])

@app.route('/hasil_klasifikasi')
def hasil_klasifikasi():
    global uploaded_data, pipeline, model_knn

    if uploaded_data is not None:
        # Lakukan klasifikasi menggunakan model yang telah ditraining sebelumnya
        X_uploaded = uploaded_data.iloc[:, :-1].values

        # Melakukan transformasi pada data menggunakan pipeline yang sudah dibuat
        X_uploaded = pipeline.transform(X_uploaded)

        predictions = model_knn.predict(X_uploaded)

        # Simpan hasil prediksi ke dalam dataframe atau variabel yang sesuai
        hasil_df = pd.DataFrame({'id_karyawan': uploaded_data['id_karyawan'], 'penerimaan': predictions})

        return render_template('hasil.html', hasil_df=hasil_df)
    else:
        # Redirect ke halaman utama jika data belum diunggah
        return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
